package ie.app.models;

/**
 * Created by ddrohan on 22/10/2015.
 */
public class Donation
{
    public int    amount;
    public String method;

    public Donation (int amount, String method)
    {
        this.amount = amount;
        this.method = method;
    }

    @Override
    public String toString() {
        return "Donation{" +
                "amount=$" + amount +
                ", method='" + method + '\'' +
                '}';
    }
}
